"""SensorCal package."""

from .app import SensorCalApp

__all__ = ["__version__", "SensorCalApp"]

__version__ = "0.1.0"
